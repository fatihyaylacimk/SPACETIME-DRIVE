# Collaboration

SPACETIME DRIVE is entering the transition from computational engineering to physical laboratory validation.

Relevant collaboration areas include:

- precision mechanical design,
- flexure mechanisms,
- anti-spring and quasi-zero-stiffness systems,
- finite-element analysis,
- precision manufacturing,
- metrology,
- force and displacement sensing,
- DAQ,
- modal testing,
- vibration analysis,
- control systems,
- uncertainty analysis,
- and FE-to-experiment correlation.

## Contact

**Fatih Yaylacı**  
Goce Delčev University — Computer Engineering  
Email: fatihyaylaci7@gmail.com  
GitHub: https://github.com/fatihyaylacimk  
LinkedIn: https://www.linkedin.com/in/fatih-yaylac%C4%B1-7ab821182
