# Scientific Scope

SPACETIME DRIVE is the project name of an engineering research program centered on a precision very-low-net-stiffness mechanical system.

This public repository does not claim experimental demonstration of warp propulsion, faster-than-light propulsion, antigravity, gravity shielding, spacetime manipulation, or reactionless propulsion.

The current validated scope includes mechanical architecture, flexure and anti-spring modeling, nonlinear/prestressed finite-element analysis, modal extraction, tolerance and robustness analysis, model-error investigation, CalculiX integration, engineering software, and preparation for physical laboratory validation.

The next scientific step is FE-to-experiment correlation using a manufactured and instrumented physical system.
