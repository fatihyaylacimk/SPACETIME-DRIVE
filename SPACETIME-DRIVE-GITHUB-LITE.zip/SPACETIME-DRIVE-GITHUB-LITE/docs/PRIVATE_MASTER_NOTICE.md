# Private Master Archive Notice

This public GitHub package is intentionally a lightweight showcase.

The complete **SPACETIME DRIVE Research Master** repository is maintained privately by **Fatih Yaylacı**. It contains the full engineering history, raw CalculiX evidence, detailed CAD assets, internal development files, locked computational release material, physical-validation preparation, integrity manifests, and unreleased research records.

Those materials are not included in this public repository.

The public repository is intended for project visibility, technical communication, selected reproducibility information, and collaboration.
