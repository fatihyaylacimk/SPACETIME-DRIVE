# Rights and Use

Copyright © 2026 Fatih Yaylacı. All rights reserved unless explicitly stated otherwise for a specific file.

This repository is made publicly visible for research communication, demonstration, academic discussion, and collaboration.

Public visibility does not automatically grant permission to reproduce, redistribute, commercially exploit, patent, relicense, or incorporate the complete work into another product.

No open-source license is granted by default.

For permission to reuse substantial project material, contact:

**fatihyaylaci7@gmail.com**

The complete SPACETIME DRIVE research master repository and unreleased technical archive remain private and are not included in this public distribution.
