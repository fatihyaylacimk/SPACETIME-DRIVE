# Security and Responsible Disclosure

Do not publish credentials, access tokens, private keys, passwords, unpublished private-repository material, or confidential collaboration data in issues or pull requests.

If you identify a security or privacy issue related to material in this repository, contact:

**fatihyaylaci7@gmail.com**
