# SPACETIME DRIVE — Türkçe Kısa Açıklama

Bu depo, SPACETIME DRIVE projesinin **herkese açık tanıtım ve işbirliği sürümüdür**.

Bu public depo tam araştırma arşivi değildir.

> **SPACETIME DRIVE'ın tam araştırma ana deposu gizli (private) olarak tutulmaktadır.**

Gizli ana depoda tam mühendislik geçmişi, ham solver çıktıları, ayrıntılı CAD dosyaları, tüm aşama kayıtları, dahili araştırma notları, bütünlük manifestleri ve henüz kamuya açılmamış teknik dosyalar bulunmaktadır.

Bu public sürümde yalnızca proje tanıtımı, seçilmiş hesaplama sonuçları, simulator ekran görüntüleri, bilimsel kapsam, mevcut durum, fiziksel doğrulama yol haritası ve işbirliği bilgileri paylaşılmaktadır.

Mevcut durumun doğru özeti:

- bilgisayar tarafı mühendisliği mevcut hesaplamalı sürüme kadar tamamlandı,
- final kalibre FE modeli 22.400 C3D20R eleman kullanıyor,
- G12 prestressed modal gate PASS,
- robust critical-corner gate PASS,
- gerçek CalculiX çalıştırması WSL üzerinden doğrulandı,
- fiziksel G13, G14 ve G15 ölçümleri bir sonraki laboratuvar aşamasıdır,
- formal asymptotic mesh convergence ayrı bir katı numerik madde olarak OPEN durumundadır.

Proje adı SPACETIME DRIVE olsa da bu çalışma warp drive, antigravity veya reactionless propulsion'ın deneysel olarak kanıtlandığı iddiasında değildir. Mevcut doğrulanmış kapsam; düşük net rijitlikli mekanik sistem, finite-element modelleme, prestressed modal analiz, tolerans/robustness çalışmaları, solver entegrasyonu ve fiziksel prototipe geçiş hazırlığıdır.

Ana İngilizce README için `README.md` dosyasına bakın.
